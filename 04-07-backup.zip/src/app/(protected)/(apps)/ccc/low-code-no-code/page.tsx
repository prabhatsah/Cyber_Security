import ScriptComponent from './components/Script';
import DryRunResult from './components/DryRunResult';

export default function LowCodeNoCode({
   
}){
    return (
    <div className="flex flex-row gap-3 w-full h-full">
        <ScriptComponent/>
        <DryRunResult/>
        
    </div> )
    
}