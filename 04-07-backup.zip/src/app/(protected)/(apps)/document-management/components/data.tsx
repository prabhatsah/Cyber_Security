const data = {
    "0": {
        inputControl: "fileInput_6c7689e0-b2fc-4a15-ae92-a0144d5d1fa3"
    }
};