
export default function Connector() {
    return (
        <div className="text-center">
          <h1>CONNECTOR COMING SOON!</h1> 
        </div>
    );
}
