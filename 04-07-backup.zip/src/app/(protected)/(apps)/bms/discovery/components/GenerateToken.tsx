export default function GenerateToken(){
    return (
        <>
        
        </>
    )
}