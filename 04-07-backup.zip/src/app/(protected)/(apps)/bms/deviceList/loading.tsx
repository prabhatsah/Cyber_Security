import { LoadingSpinner } from '@/ikon/components/loading-spinner'

function loading() {
    return (
        <LoadingSpinner size={60} />
    )
}

export default loading