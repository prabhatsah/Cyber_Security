import ConditionGeneratorDataTable from '../datatable/conditon-generator-datatable'

export function ConditionGeneratorTab() {
    return (
        <ConditionGeneratorDataTable />
    )
}
