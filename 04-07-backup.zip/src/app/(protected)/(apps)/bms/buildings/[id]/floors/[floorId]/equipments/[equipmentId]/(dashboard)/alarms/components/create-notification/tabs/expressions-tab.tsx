import ExpressionDataTable from '../datatable/expression-datatable'

export function ExpressionsTab() {
    return (
            <ExpressionDataTable />
    )
}
