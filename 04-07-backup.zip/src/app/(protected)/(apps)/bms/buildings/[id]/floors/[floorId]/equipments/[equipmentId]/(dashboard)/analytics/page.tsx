import { EnergyAnalytics } from '../../../../../../../../components/dashboard/energy-analytics'


export default function AnalyticsPage() {
  return (
    <>
    <EnergyAnalytics />
    </>
  )
}