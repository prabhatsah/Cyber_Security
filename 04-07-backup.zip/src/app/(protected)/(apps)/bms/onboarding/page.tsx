import { OnboardingPage } from '../components/onboarding/onboarding-page'


export default function Onboarding() {
  return (
    <>
      <OnboardingPage />
    </>
  )
}