import { DashboardPage } from '../components/dashboard/dashboard-page'


export default function Home() {
  return (
    <>
      <DashboardPage />
    </>
  )
}