import { LoadingSpinner } from "@/ikon/components/loading-spinner";

export default LoadingSpinner;
