import { redirect } from "next/navigation";

export default function MLManagement() {
  redirect("/ai-ml-workbench/admin/management/ml-servers");
}
