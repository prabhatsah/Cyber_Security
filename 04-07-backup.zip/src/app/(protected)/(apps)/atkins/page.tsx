import React from "react";

function page() {
  return <div>Atkins</div>;
}

export default page;
